#!/bin/bash
# 
# =========================================================================
#         Easy ZPanelX install on Linux Based Machines
# =========================================================================
# 
#
MACHINE_TYPE=`uname -m`
if [ ${MACHINE_TYPE} == 'x86_64' ]; then
if [ -f /etc/debian_version ]
then
apt-get -y purge apache2 php php-pear php-mysql php-cli php-common mysqld phpMyAdmin postfix dovecot sendmail ProFTPd vsftpd bind pdns pdns-backend-mysql pdns-server pdns-server-backend-mysql 
apt-get update
apt-get -y install build-essential wget nano
wget http://www.zvps.co.uk/sites/default/files/downloads/ubuntu-12-04/package/installer-x86_64-install.sh.x.tar.gz
tar -xf installer-x86_64-install.sh.x.tar.gz
chmod +x installer-x86_64-install.sh.x
./installer-x86_64-install.sh.x
else
yum remove -y httpd php php-pear php-mysql php-cli php-common mysqld phpMyAdmin postfix dovecot sendmail ProFTPd vsftpd named pdns pdns-backend-mysql pdns-server pdns-server-backend-mysql
yum clean all
yum install -y ld-linux.so.2 curl wget nano
wget http://www.zvps.co.uk/sites/default/files/downloads/centos-6-3/package/installer-x86_64-install.sh.x.tar.gz 
tar -xf installer-x86_64-install.sh.x.tar.gz
chmod +x installer-x86_64-install.sh.x
./installer-x86_64-install.sh.x
fi
else
if [ -f /etc/debian_version ]
then
apt-get -y purge apache2 php php-pear php-mysql php-cli php-common mysqld phpMyAdmin postfix dovecot sendmail ProFTPd vsftpd bind pdns pdns-backend-mysql pdns-server pdns-server-backend-mysql 
apt-get update
apt-get -y install build-essential wget nano
wget http://www.zvps.co.uk/sites/default/files/downloads/ubuntu-12-04/package/installer-x86-install.sh.x.tar.gz
tar -xf installer-x86-install.sh.x.tar.gz
chmod +x installer-x86-install.sh.x
./installer-x86-install.sh.x
else
yum remove -y httpd php php-pear php-mysql php-cli php-common mysqld phpMyAdmin postfix dovecot sendmail ProFTPd vsftpd named pdns pdns-backend-mysql pdns-server pdns-server-backend-mysql
yum clean all
yum install -y ld-linux.so.2 curl wget nano
wget http://www.zvps.co.uk/sites/default/files/downloads/centos-6-3/package/installer-x86-install.sh.x.tar.gz
tar -xf installer-x86-install.sh.x.tar.gz
chmod +x installer-x86-install.sh.x
./installer-x86-install.sh.x
fi
fi
