CREATE TABLE schema.table_name (
	 "field_1" INT(10) NOT NULL,
	 "field_2"" VARCHAR(20),
	 "field_3"" DATETIME,
	 "field_4"" TEXT,
	 "field_5"" BLOB,
	 PRIMARY KEY ("field_1")
)
[WITH OIDS|WITHOUT OIDS]